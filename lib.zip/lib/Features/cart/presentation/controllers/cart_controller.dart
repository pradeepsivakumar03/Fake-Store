import 'package:fake_store/Features/cart/data/repository/local_repository_impl.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/utils/messages/show_success_msg.dart';
import '../../../../core/utils/models/product_model.dart';

class CartController extends GetxController {
  final LocalRepositoryImpl localRepositoryImpl;

  CartController({required this.localRepositoryImpl});

  List<Product> cartProducts = <Product>[].obs;
  var grandTotal = 0.0.obs;

  void getProducts() {
    cartProducts.addAll(localRepositoryImpl.getProducts());
    calcTotal();
  }

  void addProduct({required Product product}) {
    localRepositoryImpl.addProduct(product: product);
    cartProducts.add(product);
    calcTotal();
    successMsg(
        title: "Cart",
        message: "${product.title} added to cart",
        bgColor: Colors.black);
  }

  void removeProduct({required Product product}) {
    localRepositoryImpl.removeProduct(product: product);
    cartProducts.remove(product);
    calcTotal();
    successMsg(
        title: "Cart",
        message: "${product.title} removed from cart",
        bgColor: Colors.black,
        icon: Icons.remove_shopping_cart_rounded);
  }

  void updateQuantity({required Product product, required int index}) {
    localRepositoryImpl.updateQuantity(product: product, index: index);
    cartProducts.insert(index, product);
  }

  void calcTotal() {
    grandTotal.value =
        cartProducts.fold(0.0, (sum, product) => sum + product.price);
  }

  @override
  void onInit() {
    getProducts();
    super.onInit();
  }
}
