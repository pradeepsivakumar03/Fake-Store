import 'package:flutter/material.dart';

class AppPalettes {
  static Color primaryColor = const Color(0xFF1E1E2F);
  static Color scaffoldBG = const Color(0xFF121212);
  static Color backgroundColor = const Color(0xFF1E1E2F);
  static Color foregroundColor = Colors.white;
}
