class ServerException {
  final String message;

  ServerException({required this.message});
}
