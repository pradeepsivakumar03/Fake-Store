import 'package:fake_store/Features/cart/presentation/bindings/local_bindings.dart';
import 'package:fake_store/Features/cart/presentation/pages/cart_page.dart';
import 'package:fake_store/Features/product%20details/presentation/pages/product_details.dart';
import 'package:fake_store/Features/products/presentation/bindings/product_binding.dart';
import 'package:fake_store/Features/products/presentation/pages/home_page.dart';
import 'package:fake_store/routes/routes.dart';
import 'package:get/get.dart';

class AppPages {
  static final routes = [
    GetPage(
      name: Routes.homePage,
      page: () => const HomePage(),
      bindings: [
        ProductBinding(),
        // LocalBindings(),
      ],
    ),
    GetPage(
      name: Routes.productDetails,
      page: () => const ProductDetailsPage(),
      binding: LocalBindings(),
    ),
    GetPage(
      name: Routes.cartPage,
      page: () => const CartPage(),
      binding: LocalBindings(),
    ),
  ];
}
