class Routes {
  static const String homePage = "/home";
  static const String productDetails = '/product-details';
  static const String cartPage = '/cart';
}
